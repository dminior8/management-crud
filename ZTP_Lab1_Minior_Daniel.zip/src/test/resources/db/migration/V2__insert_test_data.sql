INSERT INTO product (id, name, description, category, stock, price) VALUES
    ('550e8400-e29b-41d4-a716-446655440000', 'Testowy Laptop', 'Testowy opis', 'Elektronika', 99, 999.99);
