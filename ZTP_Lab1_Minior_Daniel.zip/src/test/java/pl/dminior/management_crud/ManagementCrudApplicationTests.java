package pl.dminior.management_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
